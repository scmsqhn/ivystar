#!encoding=utf-8
'''
将通用接口封装为pkg，方便调用

主要包括:
dataio 数据接口
algorithm 算法工具
web 网络接口
utils 工具
conf 配置

作者:秦海宁
时间: 2021-03-19
联系方式: 2364839934@qq.com

'''

class IvyStar(object):
    def __init__(self):
