#!encoding=utf-8

'''
相似度计算工具包
'''
