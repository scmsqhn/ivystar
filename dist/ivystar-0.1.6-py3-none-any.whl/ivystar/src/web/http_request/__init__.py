#!encoding=utf-8

'''
访问http
'''
