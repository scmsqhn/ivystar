#!encoding=utf-8

'''
模型预测工具包
'''
