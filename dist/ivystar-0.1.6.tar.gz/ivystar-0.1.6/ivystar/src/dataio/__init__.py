#!encoding=utf-8

'''
数据接口类
'''
